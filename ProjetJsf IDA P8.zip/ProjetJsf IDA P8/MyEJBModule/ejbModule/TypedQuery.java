import java.util.List;

public class TypedQuery<S> {

	public List<StudentEntity> getResultList() {
		// TODO Auto-generated method stub
		return null;
	}

}
